package lorann.game.view;

public class MainMenu {

}
