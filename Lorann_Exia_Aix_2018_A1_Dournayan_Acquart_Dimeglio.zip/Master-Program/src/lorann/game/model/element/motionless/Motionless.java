package lorann.game.model.element.motionless;

import lorann.game.model.element.Element;
import lorann.game.model.element.Permeability;

public abstract class Motionless extends Element {

	public Motionless(String imageName, char c, Permeability e) {
		super(imageName, c, e);
	}

}
