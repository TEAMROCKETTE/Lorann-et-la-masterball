package lorann.game.model.element.motionless;

import lorann.game.model.element.Permeability;

public class BoneH extends Motionless {
	
	public BoneH(){
		super("horizontal_bone", '_', Permeability.BLOCK);
	}
}
