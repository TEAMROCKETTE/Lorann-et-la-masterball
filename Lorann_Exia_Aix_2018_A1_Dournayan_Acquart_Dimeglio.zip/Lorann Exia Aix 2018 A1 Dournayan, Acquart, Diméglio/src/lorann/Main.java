package lorann;

//import java.io.IOException;
import java.util.Scanner;

import lorann.game.Lorann;
import dao.*;
public class Main {

    public static void main(String[] args) throws Exception {
        //LorannBDDConnector o;
        //o = new BDDConnector();
    	System.out.println("Put 1 - 2 - 3 - 4 - 5 - 6 - 7 for select the level");
        Scanner sc = new Scanner(System.in);
        int map = sc.nextInt();
        new LorannBDDConnector();
        new Lorann(map);
    }
}