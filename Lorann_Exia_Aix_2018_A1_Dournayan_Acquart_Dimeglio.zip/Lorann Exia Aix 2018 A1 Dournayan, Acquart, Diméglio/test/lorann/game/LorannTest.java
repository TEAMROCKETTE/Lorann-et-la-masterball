package lorann.game;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class LorannTest {
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void ExceptmapsMax(){
        try{
            new Lorann(8);
            fail("This level doesn't exist when map >7");
        }catch(final Exception e){
            final String expected = "error level";
            assertEquals(expected, e.getMessage());
        }
    }
    @Test
    public void ExceptmapsMin(){
        try{
            new Lorann(0);
            fail("This level doesn't exist when map <1");
        }catch(final Exception e){
            final String expected = "error level";
            assertEquals(expected, e.getMessage());
        }
    }
}
